import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { HomeService } from './home-service.service';
import {HttpClient} from '@angular/common/http'
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: []
})
export class HomeComponent implements OnInit {
  
  @Input() public userName: any;

  @Output() onUserClick = new EventEmitter();

  constructor(private homeService: HomeService, private fetch: HttpClient, private route: ActivatedRoute) { 
  }

  ngOnInit(): void {
    console.log(this.userName);
    this.route.data.subscribe(res => console.log(res));
    this.homeService.getUser('products');
  }

  public input: string = "products";

  // getUser()  {
  //   // this.onUserClick.emit(this.input);
  //   this.show = false;
  //   this.reason = "";
  //   this.fetch.get(`https://fakestoreapi.com/${this.input}`).subscribe(res => {
  //     this.list = res;
  //     this.reason = "";
  //     this.show = true;
  //   }, error => {
  //     this.fetch.get(`assets/${this.input}-constant.json`).subscribe(res => {
  //       this.list = res;
  //       this.reason = "";
  //       this.show = true;
  //     }, error =>   this.reason = error.name)
  //   })
  // }
  getUser() {
    this.homeService.getUser(this.input);
  }

  get list() {
    return this.homeService.list
  }

  get show() {
    return this.homeService.show;
  }

  get status() {
    return this.homeService.errorCode;
  }

  get reason() {
    return this.homeService.reason;
  }

  imageStyle(imageUrl: string): Object {
    return this.homeService.imageStyle(imageUrl);
  }
}
