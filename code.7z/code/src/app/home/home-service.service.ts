import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HomeService{

  constructor(private fetch: HttpClient) {
  }

  imageStyle(imageUrl: string):Object {
    return imageUrl ? {'background-image': `url(${imageUrl})`} : {};
  }

  public list: any = [];
  public show: boolean = false;
  public reason: string = "";
  public errorCode: number=200;
  public _currentItem: any = {};

  getUser(user: string)  {
    // this.onUserClick.emit(this.input);
    this.show = false;
    this.reason = "";
    this.fetch.get(`https://fakestoreapi.com/${user}`).subscribe(res => {
      this.list = res;
      this.reason = "";
      this.show = true;
    }, error => {
      this.fetch.get(`assets/${user}-constant.json`).subscribe(res => {
        this.list = res;
        this.reason = "";
        this.show = true;
      }, error =>   {
        this.errorCode = error.status;
        this.reason = error.name;
      })
    })
  }

  get currentItem() {
    return this._currentItem;
  }

  set currentItem(value) {
    this._currentItem = value;
  }
}
