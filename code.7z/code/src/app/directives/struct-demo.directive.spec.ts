import { StructDemoDirective } from './struct-demo.directive';

describe('StructDemoDirective', () => {
  it('should create an instance', () => {
    const directive = new StructDemoDirective();
    expect(directive).toBeTruthy();
  });
});
