import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
  selector: '[ifNot]'
})
export class StructDemoDirective {

  constructor(private view: ViewContainerRef,private templateref: TemplateRef<any>) { }

  @Input() set ifNot(value: any)  {
    if (!value) {
      this.view.createEmbeddedView(this.templateref);
    } else {
      this.view.clear();
    }
  }

}
