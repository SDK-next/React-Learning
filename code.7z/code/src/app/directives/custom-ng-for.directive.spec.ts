import { CustomNgForDirective } from './custom-ng-for.directive';

describe('CustomNgForDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomNgForDirective();
    expect(directive).toBeTruthy();
  });
});
