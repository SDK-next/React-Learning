import { Directive, TemplateRef, ViewContainerRef, Input, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';

@Directive({
  selector: '[myNgFor][myNgForOf]'
})
export class CustomNgForDirective {

  constructor(private view: ViewContainerRef,private template: TemplateRef<any>) { }

  @Input() set myNgForOf(input: Array<any>) {
    this.view.clear();

    input.forEach((item : any, index: number) => 
    {
      let double = index * 2;
      this.view.createEmbeddedView( this.template, { $implicit: item, index, double} );
    });

  }
}
