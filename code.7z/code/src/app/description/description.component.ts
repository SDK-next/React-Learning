import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HomeService } from '../home/home-service.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-description',
  templateUrl: './description.component.html',
  styleUrls: ['./description.component.css']
})
export class DescriptionComponent implements OnInit {

  public currentItem: any = [];
  constructor(private route: ActivatedRoute, private homeService: HomeService, private locate: Location) { }

  ngOnInit(): void {
    this.route.params.subscribe(res => this.currentItem = res
    );
    console.log(this.currentItem)
    this.currentItem = this.homeService.currentItem;
    console.log(this.currentItem)
  }

  goBack() {
    console.info(this.locate);
    this.locate.back();
  }

}
