import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HomeService } from '../home/home-service.service';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {

  constructor(private homeService: HomeService, private route: Router) { }

  public valueArr: number[] = [];
  public sString: string = 'Hello Welcome, How are you?';

  ngOnInit(): void {
    this.valueArr = [1, 2, 3, 4, 5];
    this.homeService.getUser('products');
  }
  
  public input: string = "products";

  getUser() {
    this.homeService.getUser(this.input);
  }

  get list() {
    return this.homeService.list
  }

  get show() {
    return this.homeService.show;
  }

  get status() {
    return this.homeService.errorCode;
  }

  get reason() {
    return this.homeService.reason;
  }

  imageStyle(imageUrl: string): Object {
    return this.homeService.imageStyle(imageUrl);
  }

  gotoProductPage(user: any, id: number) {
    console.log(user)
    this.homeService.currentItem = user;
    this.route.navigate(['/description', id])
  }

}
