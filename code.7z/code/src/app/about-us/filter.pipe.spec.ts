import { FilterPipe } from './filter.pipe';
import { CurrencyPipe } from '@angular/common';

describe('FilterPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterPipe(new CurrencyPipe('en-US'));
    expect(pipe).toBeTruthy();
  });
});
