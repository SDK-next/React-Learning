import { CurrencyPipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'totalFilter'
})
export class FilterPipe implements PipeTransform {

  public strVal: string = '';
  
  constructor(private currency: CurrencyPipe) {}
 
  transform(value: number[]): string | null {
    this.strVal = value.reduce((total, val) => val + total, 0).toString()
    
    return this.currency.transform(this.strVal);
  }

}
