import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  myForm: FormGroup = this.fb.group({
  'fieldone': ['user1', {}],
  'fieldtwo': ['user2', {}]
  })

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.handleSubmit();
  }

  handleSubmit(): void {
    console.log(this.myForm)
    console.log(this.myForm.get('fieldtwo')?.value.toLowerCase())
    console.log('hi')
  }

}
