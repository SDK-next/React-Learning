import { NgModule } from '@angular/core';
import { ActivatedRouteSnapshot, Data, RouterModule, RouterStateSnapshot, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { DescriptionComponent } from './description/description.component';
import { HomeComponent } from './home/home.component';
import { MainHomeComponent } from './main-home/main-home.component';
import { MyguardGuard } from './myguard.guard';
import { LoginComponent } from './login/login.component';
import { AuthService } from './login/auth.service';
import { FormComponent } from './form/form.component';

const title: Data = {name: 'sdk'};

const routes: Routes = [
  {path: 'home', component: FormComponent, data: title, resolve: { 
    data: (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => title}},
  {path: 'about-us', component: AboutUsComponent},
  {path: 'main-home', canActivate: [MyguardGuard], component: MainHomeComponent},
  {path: 'description/:id', component: DescriptionComponent},
  {path: 'user-login', component: LoginComponent, providers: [AuthService]},
  {path: 'form', component: FormComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
