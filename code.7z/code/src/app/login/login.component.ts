import { Component, HostListener, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { AuthService } from './auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public items: any = {
    name: 'sdk'
  }
  myForm: FormGroup= this.fb.group({
    userId: ['User', {
      validators: [Validators.minLength(6)] 
    }],
    emailId: ['abcd@gmail.com', {
      validators: [Validators.email, Validators.required]
    }],
    password: ['1234', {
      validators: [Validators.minLength(8)]
    }]
  });
  constructor(private fb: FormBuilder, private authService: AuthService) { }

  ngOnInit(): void {
  }

  show() {
    console.log(this.myForm.value);
    this.authService.isValidUser(this.myForm.get('emailId')?.value, this.myForm.get('password')?.value).subscribe(res => {
      console.log(res)
    },
    error => {
      console.log(error)
    });
  }

  @HostListener('keypress', ['$event']) setValue(e: any) {
    console.log(e);
  }
}
