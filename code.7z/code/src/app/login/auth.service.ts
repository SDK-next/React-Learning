import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EmailValidator } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private fetch: HttpClient) {
  }

  public isValidUser(email: any, password: any): Observable<any> {
    return this.fetch.post(`http://localhost:2000/api/login`, {email, password});
  }
}
