// const express = require('express');
//const cors = require('cors');

// const app = express();

// //console.log(app)
// app.use(cors());

// app.get('/list', (req, res) => {
//     console.log(req, res)
//     res.send('hi')
// })

// app.listen(2000, () => {
//     console.log('Server runnning on 2000')
// });

const express = require('express');
const bodyParser = require('body-parser');
//const cookieParser = require('cookie-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken')
const fs = require("fs");

const app = express();

app.use(bodyParser.json());
app.use(cors());

app.get('/list', (req, res) => {
        console.log(req, res)
        res.send('hi')
    })

app.route('/api/login')
    .post(loginRoute);

const RSA_PRIVATE_KEY = '1213123';

function loginRoute(req, res) {

    const email = req.body.email,
          password = req.body.password;

    if (email.length === 11) {
       const userId = email;

        const jwtBearerToken = jwt.sign({}, RSA_PRIVATE_KEY, {
                algorithm: 'RS256',
                expiresIn: 120,
                subject: userId
            })

          // send the JWT back to the user
          // TODO - multiple options available 
          res.send().status(200).json({
            idToken: jwtBearerToken, 
            expiresIn: 2
          });                             
    }
    else {
        // send status 401 Unauthorized
        res.sendStatus(401); 
    }
}

app.listen(2000, () => console.log('running'))