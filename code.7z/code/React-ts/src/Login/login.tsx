import React, { useEffect }  from "react";
import {useForm, useWatch} from 'react-hook-form';
import { SubmitHandler } from "react-hook-form/dist/types";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faS } from "@fortawesome/free-solid-svg-icons";

library.add(faS);

export function Login(props: {uname : any, uid: any}) {
    const handleSubmited= (event: any) : any => {
        console.log(event.target.value);
    };
    
    type FormValues = {
        name: string,
        id: number
    }

    const {register, handleSubmit, watch, formState: {errors}, setError} = useForm<FormValues>({defaultValues: {
        name: props.uname,
        id: props.uid
    }});

    useEffect(() => {
        watch((value, {name, type}) => {
          console.log(value, name, type)
        })
    },[watch])
    
    const  onSubmit: SubmitHandler<FormValues> = (e,data) => { console.log(data, e)};


    return <>
        <form >
          <input type='text' id='field1' key='123'  {...register('name')}/>
          <input type='number' id='field2' key='1234'  {...register('id', {max: 5
          })}/>
          {errors.id && <p>{errors.id.message}</p>}
          <input type='submit' onClick={handleSubmit(onSubmit)}/>
        </form>
    </>
}