import React, { useEffect, useState } from 'react';
import {NavLink, useNavigate} from 'react-router-dom';
import logo from './logo.svg';
import './App.css';

interface Iuser {
  name: string
};

interface Inumber extends Iuser {
  count: Iuser,
  value?: number
}

interface myArr {
  [index: number]: string, // array with index as number and value as string
}

const myfunc = <Type extends {length: number}>(val: Type): number => {
  if (val.length === 0) {
    return 1;
  } else {
    return 0;
  }
}

const map = <Input, Output>(arr: Input[], func: (arg: Input) => Output): Output[] => {
  return arr.map(func);
}
 
// Parameter 'n' is of type 'string'
// 'parsed' is of type 'number[]'
const parsed = map(["1", "2", "3"], (n) => parseInt(n));

const App = (props: { a: any }) => {
  const m = props.a;
  const [obj, setObj] = useState<Inumber>({count: {name: 'sdk'}, name: 'dk'});
  console.log(obj);

  // useEffect(() => {
  //   setObj(newObj);
  // },[newObj])

  myfunc('str')
  const strArr: myArr = ['a', 'b', 'c'];
  const navigator = useNavigate();
  const onSubmit = (res: any) : void => {
    navigator('/home', {state: strArr}); // for navigation via tsx
    console.log(res);
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.tsx</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
      <a>
        <NavLink to='/login'>Home</NavLink>
      </a>
      <button type='submit' onClick={(res) => onSubmit(res)}>click me</button>
    </div>
  );
}

export default App;
