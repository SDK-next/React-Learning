import React from "react";
import { useLocation } from "react-router-dom";

export function Home() {
   const navigation = useLocation(); // To get navigation datas
   console.log(navigation)
   return <>
        <h1>Hi in Home Page</h1>
   </> 
}